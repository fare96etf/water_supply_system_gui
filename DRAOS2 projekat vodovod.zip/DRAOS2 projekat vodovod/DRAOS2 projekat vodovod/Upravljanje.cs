﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web;

namespace DRAOS2_projekat_vodovod
{
    public partial class Upravljanje : Form
    {
        Klasa_Vodovod v;
        Klasa_Inzinjer eng;
        public Upravljanje(Klasa_Vodovod vod)
        {
            InitializeComponent();
            v = vod;
            radioButton_nadzor.Checked = true;
            label_status_ime.Text = "ADMINISTRATOR";
            radioButton_v1.Checked = true;
            statusStrip_safe.ForeColor = Color.Red;
            tb_p1_protok.Text = vod.safe_mode[0].ToString();
            tb_p2_protok.Text = vod.safe_mode[1].ToString();
            tb_v1_protok.Text = vod.safe_mode[2].ToString();
            tb_v2_protok.Text = vod.safe_mode[3].ToString();
            tb_p1_pritisak.Text = vod.safe_mode[4].ToString();
            tb_p2_pritisak.Text = vod.safe_mode[5].ToString();
            tb_v1_pritisak.Text = vod.safe_mode[6].ToString();
            tb_v2_pritisak.Text = vod.safe_mode[7].ToString();
            textBox_protok.Text = vod.vrijednosti[0].ToString();
            textBox_pritisak.Text = vod.vrijednosti[4].ToString();
            textBox_nivo.Text = vod.vrijednosti[8].ToString();
            textBox_ph.Text = vod.vrijednosti[9].ToString();
            tb_nivo.Text = vod.safe_mode[8].ToString();
            tb_ph.Text = vod.safe_mode[9].ToString();
            textBox_trenutna.Text = v.vrijednosti[10].ToString();
            radioButton_hv1.Checked = true;
            radioButton_prot_nivo.Checked = true;
            textBox_nivo_srednja.Text = v.statistika[32].ToString();
            textBox_nivo_max.Text = v.statistika[33].ToString();
            textBox_nivo_min.Text = v.statistika[34].ToString();
            textBox_nivo_prom.Text = v.statistika[35].ToString();
            textBox_ph_srednja.Text = v.statistika[36].ToString();
            textBox_ph_max.Text = v.statistika[37].ToString();
            textBox_ph_min.Text = v.statistika[38].ToString();
            textBox_ph_prom.Text = v.statistika[39].ToString();

            textBox_protok_srednja.Text = v.statistika[0].ToString();
            textBox_protok_max.Text = v.statistika[1].ToString();
            textBox_protok_min.Text = v.statistika[2].ToString();
            textBox_protok_prom.Text = v.statistika[3].ToString();
            textBox_pritisak_srednja.Text = v.statistika[4].ToString();
            textBox_pritisak_max.Text = v.statistika[5].ToString();
            textBox_pritisak_min.Text = v.statistika[6].ToString();
            textBox_pritisak_prom.Text = v.statistika[7].ToString();

        }

        public Upravljanje(Klasa_Vodovod vod, Klasa_Inzinjer e)
        {
            InitializeComponent();
            radioButton_nadzor.Checked = true;
            v = vod;
            eng = e;
            label_status_ime.Text = e.Ime + ": " + e.Pozicija;
            radioButton_v1.Checked = true;
            statusStrip_safe.ForeColor = Color.Red;
            tb_p1_protok.Text = vod.safe_mode[0].ToString();
            tb_p2_protok.Text = vod.safe_mode[1].ToString();
            tb_v1_protok.Text = vod.safe_mode[2].ToString();
            tb_v2_protok.Text = vod.safe_mode[3].ToString();
            tb_p1_pritisak.Text = vod.safe_mode[4].ToString();
            tb_p2_pritisak.Text = vod.safe_mode[5].ToString();
            tb_v1_pritisak.Text = vod.safe_mode[6].ToString();
            tb_v2_pritisak.Text = vod.safe_mode[7].ToString();
            textBox_protok.Text = vod.vrijednosti[0].ToString();
            textBox_pritisak.Text = vod.vrijednosti[4].ToString();
            textBox_nivo.Text = vod.vrijednosti[8].ToString();
            textBox_ph.Text = vod.vrijednosti[9].ToString();
            tb_nivo.Text = vod.safe_mode[8].ToString();
            tb_ph.Text = vod.safe_mode[9].ToString();
            textBox_trenutna.Text = v.vrijednosti[10].ToString();
            radioButton_hv1.Checked = true;
            radioButton_prot_nivo.Checked = true;
            textBox_nivo_srednja.Text = v.statistika[32].ToString();
            textBox_nivo_max.Text = v.statistika[33].ToString();
            textBox_nivo_min.Text = v.statistika[34].ToString();
            textBox_nivo_prom.Text = v.statistika[35].ToString();
            textBox_ph_srednja.Text = v.statistika[36].ToString();
            textBox_ph_max.Text = v.statistika[37].ToString();
            textBox_ph_min.Text = v.statistika[38].ToString();
            textBox_ph_prom.Text = v.statistika[39].ToString();

            textBox_protok_srednja.Text = v.statistika[0].ToString();
            textBox_protok_max.Text = v.statistika[1].ToString();
            textBox_protok_min.Text = v.statistika[2].ToString();
            textBox_protok_prom.Text = v.statistika[3].ToString();
            textBox_pritisak_srednja.Text = v.statistika[4].ToString();
            textBox_pritisak_max.Text = v.statistika[5].ToString();
            textBox_pritisak_min.Text = v.statistika[6].ToString();
            textBox_pritisak_prom.Text = v.statistika[7].ToString();
        }



        private void Upravljanje_Load(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            trackBar_trenutna.Value = Convert.ToInt32(numericUpDown_trenutna.Value);
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            numericUpDown_trenutna.Value = Convert.ToDecimal(trackBar_trenutna.Value);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            v.vrijednosti[8] = Convert.ToDouble(textBox_nivo.Text);
            v.vrijednosti[9] = Convert.ToDouble(textBox_ph.Text);

            if (radioButton_v1.Checked == true)
            {
                v.vrijednosti[0] = Convert.ToDouble(textBox_protok.Text);
                v.vrijednosti[4] = Convert.ToDouble(textBox_pritisak.Text);
            }
            if (radioButton_v2.Checked == true)
            {
                v.vrijednosti[1] = Convert.ToDouble(textBox_protok.Text);
                v.vrijednosti[5] = Convert.ToDouble(textBox_pritisak.Text);
            }
            if (radioButton_p1.Checked == true)
            {
                v.vrijednosti[2] = Convert.ToDouble(textBox_protok.Text);
                v.vrijednosti[6] = Convert.ToDouble(textBox_pritisak.Text);
            }
            if (radioButton_p2.Checked == true)
            {
                v.vrijednosti[3] = Convert.ToDouble(textBox_protok.Text);
                v.vrijednosti[7] = Convert.ToDouble(textBox_pritisak.Text);
            }
            MessageBox.Show("Uspješno ste promijenili parametre!", "OBAVIJEST");
        }

        private void radioButton_p2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_p2.Checked == true)
            {
                groupBox_pp.Text = "PUMPA 2";
                textBox_protok.Text = v.vrijednosti[3].ToString();
                textBox_pritisak.Text = v.vrijednosti[7].ToString();
                textBox_trenutna.Text = v.vrijednosti[13].ToString();
                numericUpDown_trenutna.Value = Convert.ToDecimal(v.vrijednosti[13]);
                trackBar_trenutna.Value = Convert.ToInt32(v.vrijednosti[13]);
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void chart2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox8_Enter(object sender, EventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_odjava_Click(object sender, EventArgs e)
        {
            Pocetna p = new Pocetna(v);
            this.Hide();
            p.ShowDialog();
            this.Close();
        }

        private void radioButton_nadzor_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_nadzor.Checked == true)
            {
                button_reset_lijevi.Enabled = false;
                button_reset_desni.Enabled = false;
                button_promjene_lijevo.Enabled = false;
                button_promjene_desno.Enabled = false;
                numericUpDown_trenutna.Enabled = false;
                trackBar_trenutna.Enabled = false;
                groupBox_lijevi.Text = "Ulazne veličine";
                groupBox_desni.Text = "Izlazne veličine";
                textBox_protok.ReadOnly = true;
                textBox_pritisak.ReadOnly = true;
                textBox_nivo.ReadOnly = true;
                textBox_ph.ReadOnly = true;
            }
        }

        private void radioButton_man_up_CheckedChanged(object sender, EventArgs e)
        {
            button_reset_lijevi.Enabled = true;
            button_reset_desni.Enabled = false;
            button_promjene_lijevo.Enabled = true;
            button_promjene_desno.Enabled = false;
            numericUpDown_trenutna.Enabled = true;
            trackBar_trenutna.Enabled = true;
            groupBox_lijevi.Text = "Manuelno upravljanje";
            groupBox_desni.Text = "Izlazne veličine";
            textBox_protok.ReadOnly = true;
            textBox_pritisak.ReadOnly = true;
            textBox_nivo.ReadOnly = true;
            textBox_ph.ReadOnly = true;
        }

        private void radioButton_aut_up_CheckedChanged(object sender, EventArgs e)
        {
            button_reset_lijevi.Enabled = false;
            button_reset_desni.Enabled = true;
            button_promjene_lijevo.Enabled = false;
            button_promjene_desno.Enabled = true;
            numericUpDown_trenutna.Enabled = false;
            trackBar_trenutna.Enabled = false;
            groupBox_lijevi.Text = "Ulazne veličine";
            groupBox_desni.Text = "Automatsko upravljanje";
            textBox_protok.ReadOnly = false;
            textBox_pritisak.ReadOnly = false;
            textBox_nivo.ReadOnly = false;
            textBox_ph.ReadOnly = false;
        }

        private void button_nazad_Click(object sender, EventArgs e)
        {
            if (eng == null)
            {
                Admin admin = new Admin(v);
                this.Hide();
                admin.ShowDialog();
                this.Close();
            }
            Inzinjer eng_forma = new Inzinjer(v, eng);
            this.Hide();
            eng_forma.ShowDialog();
            this.Close();
        }

        private void radioButton_v1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_v1.Checked == true)
            {
                groupBox_pp.Text = "VENTIL 1";
                textBox_protok.Text = v.vrijednosti[0].ToString();
                textBox_pritisak.Text = v.vrijednosti[4].ToString();
                textBox_nivo.Text = v.vrijednosti[8].ToString();
                textBox_ph.Text = v.vrijednosti[9].ToString();
                textBox_trenutna.Text = v.vrijednosti[10].ToString();
                numericUpDown_trenutna.Value = Convert.ToDecimal(v.vrijednosti[10]);
                trackBar_trenutna.Value = Convert.ToInt32(v.vrijednosti[10]);
            }
            
        }

        private void radioButton_v2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_v2.Checked == true)
            {
                groupBox_pp.Text = "VENTIL 2";
                textBox_protok.Text = v.vrijednosti[1].ToString();
                textBox_pritisak.Text = v.vrijednosti[5].ToString();
                textBox_trenutna.Text = v.vrijednosti[11].ToString();
                numericUpDown_trenutna.Value = Convert.ToDecimal(v.vrijednosti[11]);
                trackBar_trenutna.Value = Convert.ToInt32(v.vrijednosti[11]);
            }
            
        }

        private void radioButton_p1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_p1.Checked == true)
            {
                groupBox_pp.Text = "PUMPA 1";
                textBox_protok.Text = v.vrijednosti[2].ToString();
                textBox_pritisak.Text = v.vrijednosti[6].ToString();
                textBox_trenutna.Text = v.vrijednosti[12].ToString();
                numericUpDown_trenutna.Value = Convert.ToDecimal(v.vrijednosti[12]);
                trackBar_trenutna.Value = Convert.ToInt32(v.vrijednosti[12]);
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            tb_v1_protok.Text = v.safe_mode[0].ToString();
            tb_v2_protok.Text = v.safe_mode[1].ToString();
            tb_p1_protok.Text = v.safe_mode[2].ToString();
            tb_p2_protok.Text = v.safe_mode[3].ToString();
            tb_v1_pritisak.Text = v.safe_mode[4].ToString();
            tb_v2_pritisak.Text = v.safe_mode[5].ToString();
            tb_p1_pritisak.Text = v.safe_mode[6].ToString();
            tb_p2_pritisak.Text = v.safe_mode[7].ToString();
            tb_nivo.Text = v.safe_mode[8].ToString();
            tb_ph.Text = v.safe_mode[9].ToString();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            double b0, b1, b2, b3, b4, b5, b6, b7, b8, b9;
            int provjera = 0;
            if (!Double.TryParse(tb_v1_protok.Text, out b0)) provjera = 1;
            if (!Double.TryParse(tb_v2_protok.Text, out b1)) provjera = 1;
            if (!Double.TryParse(tb_p1_protok.Text, out b2)) provjera = 1;
            if (!Double.TryParse(tb_p2_protok.Text, out b3)) provjera = 1;
            if (!Double.TryParse(tb_v1_pritisak.Text, out b4)) provjera = 1;
            if (!Double.TryParse(tb_v2_pritisak.Text, out b5)) provjera = 1;
            if (!Double.TryParse(tb_p1_pritisak.Text, out b6)) provjera = 1;
            if (!Double.TryParse(tb_p2_pritisak.Text, out b7)) provjera = 1;
            if (!Double.TryParse(tb_nivo.Text, out b8)) provjera = 1;
            if (!Double.TryParse(tb_ph.Text, out b9)) provjera = 1;
            
            if (provjera == 0)
            {
                toolStripStatus_safe.Text = "";
                v.safe_mode[0] = b0;
                v.safe_mode[1] = b1;
                v.safe_mode[2] = b2;
                v.safe_mode[3] = b3;
                v.safe_mode[4] = b4;
                v.safe_mode[5] = b5;
                v.safe_mode[6] = b6;
                v.safe_mode[7] = b7;
                v.safe_mode[8] = b8;
                v.safe_mode[9] = b9;
                tb_v1_protok.Text = v.safe_mode[0].ToString();
                tb_v2_protok.Text = v.safe_mode[1].ToString();
                tb_p1_protok.Text = v.safe_mode[2].ToString();
                tb_p2_protok.Text = v.safe_mode[3].ToString();
                tb_v1_pritisak.Text = v.safe_mode[4].ToString();
                tb_v2_pritisak.Text = v.safe_mode[5].ToString();
                tb_p1_pritisak.Text = v.safe_mode[6].ToString();
                tb_p2_pritisak.Text = v.safe_mode[7].ToString();
                tb_nivo.Text = v.safe_mode[8].ToString();
                tb_ph.Text = v.safe_mode[9].ToString();
                MessageBox.Show("Uspješno ste promijenili parametre!", "OBAVIJEST");
            }

            if (provjera == 1)
            {
                toolStripStatus_safe.Text = "Pogrešan unos!";
            }
        }

        private void statusStrip_safe_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= 9; i++)
            {
                v.vrijednosti[i] = v.safe_mode[i];
            }
            radioButton_v1.Checked = false;
            radioButton_v1.Checked = true;

      
        }

        private void button_reset_lijevi_Click(object sender, EventArgs e)
        {
            if (radioButton_v1.Checked == true)
            {
                numericUpDown_trenutna.Value = Convert.ToDecimal(v.vrijednosti[10]);
                trackBar_trenutna.Value = Convert.ToInt32(v.vrijednosti[10]);
            }
            if (radioButton_v2.Checked == true)
            {
                numericUpDown_trenutna.Value = Convert.ToDecimal(v.vrijednosti[11]);
                trackBar_trenutna.Value = Convert.ToInt32(v.vrijednosti[11]);
            }
            if (radioButton_p1.Checked == true)
            {
                numericUpDown_trenutna.Value = Convert.ToDecimal(v.vrijednosti[12]);
                trackBar_trenutna.Value = Convert.ToInt32(v.vrijednosti[12]);
            }
            if (radioButton_p2.Checked == true)
            {
                numericUpDown_trenutna.Value = Convert.ToDecimal(v.vrijednosti[13]);
                trackBar_trenutna.Value = Convert.ToInt32(v.vrijednosti[13]);
            }
        }

        private void button_promjene_lijevo_Click(object sender, EventArgs e)
        {
            if (radioButton_v1.Checked == true)
            {
                v.vrijednosti[10] = Convert.ToDouble(numericUpDown_trenutna.Value);
                textBox_trenutna.Text = v.vrijednosti[10].ToString();
                MessageBox.Show("Uspješno ste promijenili parametre!", "OBAVIJEST");
            }
            if (radioButton_v2.Checked == true)
            {
                v.vrijednosti[11] = Convert.ToDouble(numericUpDown_trenutna.Value);
                textBox_trenutna.Text = v.vrijednosti[11].ToString();
                MessageBox.Show("Uspješno ste promijenili parametre!", "OBAVIJEST");
            }
            if (radioButton_p1.Checked == true)
            {
                v.vrijednosti[12] = Convert.ToDouble(numericUpDown_trenutna.Value);
                textBox_trenutna.Text = v.vrijednosti[12].ToString();
                MessageBox.Show("Uspješno ste promijenili parametre!", "OBAVIJEST");
            }
            if (radioButton_p2.Checked == true)
            {
                v.vrijednosti[13] = Convert.ToDouble(numericUpDown_trenutna.Value);
                textBox_trenutna.Text = v.vrijednosti[13].ToString();
                MessageBox.Show("Uspješno ste promijenili parametre!", "OBAVIJEST");
            }
        }

        private void button_reset_desni_Click(object sender, EventArgs e)
        {
            textBox_nivo.Text = v.vrijednosti[8].ToString();
            textBox_ph.Text = v.vrijednosti[9].ToString();
            
            if (radioButton_v1.Checked == true)
            {
                textBox_protok.Text = v.vrijednosti[0].ToString();
                textBox_pritisak.Text = v.vrijednosti[4].ToString();
            }
            if (radioButton_v2.Checked == true)
            {
                textBox_protok.Text = v.vrijednosti[1].ToString();
                textBox_pritisak.Text = v.vrijednosti[5].ToString();
            }
            if (radioButton_p1.Checked == true)
            {
                textBox_protok.Text = v.vrijednosti[2].ToString();
                textBox_pritisak.Text = v.vrijednosti[6].ToString();
            }
            if (radioButton_p2.Checked == true)
            {
                textBox_protok.Text = v.vrijednosti[3].ToString();
                textBox_pritisak.Text = v.vrijednosti[7].ToString();
            }
        }

        private void radioButton_hv1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_hv1.Checked == true)
            {
                if (radioButton_prot_nivo.Checked == true)
                {
                    groupBox_graf.Text = "Protok (Ventil 1)";
                    groupBox_dnevna.Text = "Ventil 1";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.protok_v1[i]);
                    }
                }
                if (radioButton_prit_ph.Checked == true)
                {
                    groupBox_graf.Text = "Pritisak (Ventil 1)";
                    groupBox_dnevna.Text = "Ventil 1";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.pritisak_v1[i]);
                    }
                }
                textBox_protok_srednja.Text = v.statistika[0].ToString();
                textBox_protok_max.Text = v.statistika[1].ToString();
                textBox_protok_min.Text = v.statistika[2].ToString();
                textBox_protok_prom.Text = v.statistika[3].ToString();
                textBox_pritisak_srednja.Text = v.statistika[4].ToString();
                textBox_pritisak_max.Text = v.statistika[5].ToString();
                textBox_pritisak_min.Text = v.statistika[6].ToString();
                textBox_pritisak_prom.Text = v.statistika[7].ToString();
            }
        }

        private void radioButton_hv2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_hv2.Checked == true)
            {
                if (radioButton_prot_nivo.Checked == true)
                {
                    groupBox_graf.Text = "Protok (Ventil 2)";
                    groupBox_dnevna.Text = "Ventil 2";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.protok_v2[i]);
                    }
                }
                if (radioButton_prit_ph.Checked == true)
                {
                    groupBox_graf.Text = "Pritisak (Ventil 2)";
                    groupBox_dnevna.Text = "Ventil 2";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.pritisak_v2[i]);
                    }
                }
                textBox_protok_srednja.Text = v.statistika[8].ToString();
                textBox_protok_max.Text = v.statistika[9].ToString();
                textBox_protok_min.Text = v.statistika[10].ToString();
                textBox_protok_prom.Text = v.statistika[11].ToString();
                textBox_pritisak_srednja.Text = v.statistika[12].ToString();
                textBox_pritisak_max.Text = v.statistika[13].ToString();
                textBox_pritisak_min.Text = v.statistika[14].ToString();
                textBox_pritisak_prom.Text = v.statistika[15].ToString();
            }
        }

        private void radioButton_hp1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_hp1.Checked == true)
            {
                if (radioButton_prot_nivo.Checked == true)
                {
                    groupBox_graf.Text = "Protok (Pumpa 1)";
                    groupBox_dnevna.Text = "Pumpa 1";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.protok_p1[i]);
                    }
                }
                if (radioButton_prit_ph.Checked == true)
                {
                    groupBox_graf.Text = "Pritisak (Pumpa 1)";
                    groupBox_dnevna.Text = "Pumpa 1";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.pritisak_p1[i]);
                    }
                }
                textBox_protok_srednja.Text = v.statistika[16].ToString();
                textBox_protok_max.Text = v.statistika[17].ToString();
                textBox_protok_min.Text = v.statistika[18].ToString();
                textBox_protok_prom.Text = v.statistika[19].ToString();
                textBox_pritisak_srednja.Text = v.statistika[20].ToString();
                textBox_pritisak_max.Text = v.statistika[21].ToString();
                textBox_pritisak_min.Text = v.statistika[22].ToString();
                textBox_pritisak_prom.Text = v.statistika[23].ToString();
            }
        }

        private void radioButton_hp2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_hp2.Checked == true)
            {
                if (radioButton_prot_nivo.Checked == true)
                {
                    groupBox_graf.Text = "Protok (Pumpa 2)";
                    groupBox_dnevna.Text = "Pumpa 2";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.protok_p2[i]);
                    }
                }
                if (radioButton_prit_ph.Checked == true)
                {
                    groupBox_graf.Text = "Pritisak (Pumpa 2)";
                    groupBox_dnevna.Text = "Pumpa 2";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.pritisak_p2[i]);
                    }
                }
                textBox_protok_srednja.Text = v.statistika[24].ToString();
                textBox_protok_max.Text = v.statistika[25].ToString();
                textBox_protok_min.Text = v.statistika[26].ToString();
                textBox_protok_prom.Text = v.statistika[27].ToString();
                textBox_pritisak_srednja.Text = v.statistika[28].ToString();
                textBox_pritisak_max.Text = v.statistika[29].ToString();
                textBox_pritisak_min.Text = v.statistika[30].ToString();
                textBox_pritisak_prom.Text = v.statistika[31].ToString();
            }
        }


        private void radioButton_prot_nivo_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_prot_nivo.Checked == true)
            {
                if (radioButton_hv1.Checked == true)
                {
                    groupBox_graf.Text = "Protok (Ventil 1)";
                    groupBox_dnevna.Text = "Ventil 1";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.protok_v1[i]);
                    }
                }
                if (radioButton_hv2.Checked == true)
                {
                    groupBox_graf.Text = "Protok (Ventil 2)";
                    groupBox_dnevna.Text = "Ventil 2";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.protok_v2[i]);
                    }
                }
                if (radioButton_hp1.Checked == true)
                {
                    groupBox_graf.Text = "Protok (Pumpa 1)";
                    groupBox_dnevna.Text = "Pumpa 1";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.protok_p1[i]);
                    }
                }
                if (radioButton_hp2.Checked == true)
                {
                    groupBox_graf.Text = "Protok (Pumpa 2)";
                    groupBox_dnevna.Text = "Pumpa 2";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.protok_p2[i]);
                    }
                }
               
            }
        }

        private void radioButton_prit_ph_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_prit_ph.Checked == true)
            {
                if (radioButton_hv1.Checked == true)
                {
                    groupBox_graf.Text = "Pritisak (Ventil 1)";
                    groupBox_dnevna.Text = "Ventil 1";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.pritisak_v1[i]);
                    }
                }
                if (radioButton_hv2.Checked == true)
                {
                    groupBox_graf.Text = "Pritisak (Ventil 2)";
                    groupBox_dnevna.Text = "Ventil 2";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.pritisak_v2[i]);
                    }
                }
                if (radioButton_hp1.Checked == true)
                {
                    groupBox_graf.Text = "Pritisak (Pumpa 1)";
                    groupBox_dnevna.Text = "Pumpa 1";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.pritisak_p1[i]);
                    }
                }
                if (radioButton_hp2.Checked == true)
                {
                    groupBox_graf.Text = "Pritisak (Pumpa 2)";
                    groupBox_dnevna.Text = "Pumpa 2";
                    chart2.Series.Clear();
                    for (int i = 0; i < 12; i++)
                    {
                        chart2.Series.Add(v.mjeseci[i]);
                        chart2.Series[i].Points.Add(v.pritisak_p2[i]);
                    }
                }
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
    }
}
