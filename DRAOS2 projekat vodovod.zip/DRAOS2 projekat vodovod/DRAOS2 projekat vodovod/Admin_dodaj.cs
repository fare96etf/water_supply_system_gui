﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DRAOS2_projekat_vodovod
{
    public partial class Admin_dodaj : Form
    {
        public Klasa_Vodovod v;
        public Admin_dodaj()
        {
            InitializeComponent();
        }

        public Admin_dodaj(Klasa_Vodovod vod)
        {
            InitializeComponent();
            v = vod;
            radioButton_eng.Checked = true;
            toolStripStatusLabel_dodaj.Text = "";
        }

        private void button_odjava_Click(object sender, EventArgs e)
        {
            Pocetna p = new Pocetna(v);
            this.Hide();
            p.ShowDialog();
            this.Close();
        }

        private void button_nazad_Click(object sender, EventArgs e)
        {
            Admin admin = new Admin(v);
            this.Hide();
            admin.ShowDialog();
            this.Close();
        }

        private void Admin_dodaj_Load(object sender, EventArgs e)
        {

        }

        private void button_potvrda_Click(object sender, EventArgs e)
        {
            int provjera = 0;
            if (string.IsNullOrWhiteSpace(textBox_ime.Text)) provjera = 1;
            if (string.IsNullOrWhiteSpace(textBox_mail.Text)) provjera = 1;
            if (string.IsNullOrWhiteSpace(textBox_tel.Text)) provjera = 1;
            if (string.IsNullOrWhiteSpace(textBox_un.Text)) provjera = 1;
            if (string.IsNullOrWhiteSpace(textBox_pass.Text)) provjera = 1;
            if (radioButton_eng.Checked == true && provjera == 0)
            {
                toolStripStatusLabel_dodaj.Text = "";
                Klasa_Inzinjer eng = new Klasa_Inzinjer(textBox_ime.Text, textBox_mail.Text, textBox_tel.Text, textBox_un.Text, textBox_pass.Text);
                v.inzinjeri.Add(eng);
                MessageBox.Show("Korisnik je uspješno dodan!", "OBAVIJEST");
            }
                
                
            if (radioButton_tech.Checked == true && provjera == 0)
            {
                toolStripStatusLabel_dodaj.Text = "";
                Klasa_Tehnolog tech = new Klasa_Tehnolog(textBox_ime.Text, textBox_mail.Text, textBox_tel.Text, textBox_un.Text, textBox_pass.Text);
                v.tehnolozi.Add(tech);
                MessageBox.Show("Korisnik je uspješno dodan!", "OBAVIJEST");
            }
                
            if (provjera == 1)
            {
                toolStripStatusLabel_dodaj.Text = "Pogrešan unos!";
            }
            

        }
    }
}
