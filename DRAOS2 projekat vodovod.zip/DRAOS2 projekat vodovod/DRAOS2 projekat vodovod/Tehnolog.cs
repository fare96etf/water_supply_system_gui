﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace DRAOS2_projekat_vodovod
{
    public partial class Tehnolog : Form
    {
        Klasa_Vodovod v;
        Klasa_Tehnolog tech;
        public Tehnolog()
        {
            InitializeComponent();
        }

        public Tehnolog(Klasa_Vodovod vod, Klasa_Tehnolog t)
        {
            InitializeComponent();
            v = vod;
            tech = t;
            textBox_ime.Text = t.Ime;
            textBox_mail.Text = t.Mail;
            textBox_pozicija.Text = t.Pozicija;
            textBox_telefon.Text = t.Telefon;
        }

        private void Tehnolog_Load(object sender, EventArgs e)
        {

        }

        private void button_odjava_Click(object sender, EventArgs e)
        {
            Pocetna p = new Pocetna(v);
            this.Hide();
            p.ShowDialog();
            this.Close();
        }

        private void button_nadzor_Click(object sender, EventArgs e)
        {
            Nadzor u = new Nadzor(v, tech);
            this.Hide();
            u.ShowDialog();
            this.Close();
        }

        private void button_tabla_Click(object sender, EventArgs e)
        {
            OglasnaTabla o = new OglasnaTabla(v, tech);
            this.Hide();
            o.ShowDialog();
            this.Close();
        }

        private void button_upute_Click(object sender, EventArgs e)
        {
            var path = Path.GetDirectoryName(Application.StartupPath) + "\\DRAOS2_upute_teh.pdf";
            System.Diagnostics.Process.Start(path);
        }
    }
}
