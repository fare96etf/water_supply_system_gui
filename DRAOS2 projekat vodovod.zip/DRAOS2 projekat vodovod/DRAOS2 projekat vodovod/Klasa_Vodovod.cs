﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DRAOS2_projekat_vodovod
{
    public class Klasa_Vodovod
    {
        //atributi
        public List<Klasa_Inzinjer> inzinjeri = new List<Klasa_Inzinjer>();
        public List<Klasa_Tehnolog> tehnolozi = new List<Klasa_Tehnolog>();
        public string admin_username = "fare";
        public string admin_password = "123";
        public List<string> oglasna = new List<string>() { "Jučer je sve ispravno radilo." };
        public List<double> safe_mode = new List<double>() { 50, 50, 50, 50, 5, 5, 5, 5, 500, 0.2 };
        public List<double> vrijednosti = new List<double>() { 40, 41, 42, 43, 4, 5, 6, 7, 500, 0.2, 80, 81, 82, 83 };
        public List<double> statistika = new List<double>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 };
        public List<string> mjeseci = new List<string>() { "Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar", "Oktobar", "Novembar", "Decembar" };

        public List<double> protok_v1 = new List<double>() { 1, 20, 30, 40, 50, 60, 70, 80, 90, 10, 11, 12 };
        public List<double> protok_v2 = new List<double>() { 30, 22, 33, 44, 51, 63, 71, 82, 92, 12, 17, 14 };
        public List<double> protok_p1 = new List<double>() { 5, 23, 34, 45, 52, 64, 72, 84, 94, 13, 11, 12 };
        public List<double> protok_p2 = new List<double>() { 50, 20, 30, 47, 55, 68, 74, 83, 99, 10, 11, 12 };
        public List<double> pritisak_v1 = new List<double>() { 10, 20, 36, 40, 57, 69, 78, 80, 90, 10, 11, 12 };
        public List<double> pritisak_v2 = new List<double>() { 1, 20, 30, 41, 50, 60, 77, 80, 96, 10, 11, 12 };
        public List<double> pritisak_p1 = new List<double>() { 10, 22, 33, 4, 5, 60, 74, 80, 90, 10, 11, 12 };
        public List<double> pritisak_p2 = new List<double>() { 10, 20, 37, 40, 50, 6, 77, 88, 9, 10, 11, 12 };

        //konstruktori
        public Klasa_Vodovod()
        {
            Klasa_Inzinjer eng1 = new Klasa_Inzinjer("Nahla Šalaka", "nahla@vodovod.com", "0123", "nahla", "abc");
            inzinjeri.Add(eng1);
            Klasa_Tehnolog tech1 = new Klasa_Tehnolog("Amina Džebo", "amina@vodovod.com", "3210", "amina", "abcd");
            tehnolozi.Add(tech1);
        }

        //metode
        public void Dodaj_Inzinjera (string i, string m, string tel, string un, string pass)
        {
            //provjeriti da se ne preklapa username
            Klasa_Inzinjer eng = new Klasa_Inzinjer(i, m, tel, un, pass);
            inzinjeri.Add(eng);
        }

        public void Dodaj_Tehnologa(string i, string m, string tel, string un, string pass)
        {
            //provjeriti da se ne preklapa username
            Klasa_Tehnolog tech = new Klasa_Tehnolog(i, m, tel, un, pass);
            tehnolozi.Add(tech);
        }

        public void Obrisi_Inzinjera (int id)
        {
            foreach (Klasa_Inzinjer eng in inzinjeri)
            {
                if (eng.ID == id) inzinjeri.Remove(eng);
            }
        }

        public void Obrisi_Tehnologa(int id)
        {
            foreach (Klasa_Tehnolog tech in tehnolozi)
            {
                if (tech.ID == id) tehnolozi.Remove(tech);
            }
        }

        public Klasa_Inzinjer Pretrazi_Inzinjere (string un, string pass)
        {
            foreach (Klasa_Inzinjer eng in inzinjeri)
            {
                if (eng.Username == un && eng.Password == pass) return eng;            
            }
            return null;
        }

        public Klasa_Tehnolog Pretrazi_Tehnologe(string un, string pass)
        {
            foreach (Klasa_Tehnolog tech in tehnolozi)
            {
                if (tech.Username == un && tech.Password == pass) return tech;
            }
            return null;
        }
    }
}
