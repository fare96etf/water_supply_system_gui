﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace DRAOS2_projekat_vodovod
{
    public partial class Inzinjer : Form
    {
        Klasa_Vodovod v;
        Klasa_Inzinjer eng;
        public Inzinjer()
        {
            InitializeComponent();
        }

        public Inzinjer(Klasa_Vodovod vod, Klasa_Inzinjer e)
        {
            InitializeComponent();
            v = vod;
            eng = e;
            textBox_ime.Text = eng.Ime;
            textBox_mail.Text = eng.Mail;
            textBox_pozicija.Text = eng.Pozicija;
            textBox_telefon.Text = eng.Telefon;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Inzinjer_Load(object sender, EventArgs e)
        {

        }

        private void button_odjava_Click(object sender, EventArgs e)
        {
            Pocetna p = new Pocetna(v);
            this.Hide();
            p.ShowDialog();
            this.Close();
        }

        private void button_nadzor_Click(object sender, EventArgs e)
        {
            Upravljanje u = new Upravljanje(v, eng);
            this.Hide();
            u.ShowDialog();
            this.Close();
        }

        private void button_tabla_Click(object sender, EventArgs e)
        {
            OglasnaTabla o = new OglasnaTabla(v, eng);
            this.Hide();
            o.ShowDialog();
            this.Close();
        }

        private void button_upute_Click(object sender, EventArgs e)
        {
            var path = Path.GetDirectoryName(Application.StartupPath) + "\\DRAOS2_upute_ing.pdf";
            System.Diagnostics.Process.Start(path);
           


        }
    }
}
