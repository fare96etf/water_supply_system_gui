﻿namespace DRAOS2_projekat_vodovod
{
    partial class Inzinjer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_telefon = new System.Windows.Forms.TextBox();
            this.textBox_mail = new System.Windows.Forms.TextBox();
            this.textBox_pozicija = new System.Windows.Forms.TextBox();
            this.textBox_ime = new System.Windows.Forms.TextBox();
            this.Opcije = new System.Windows.Forms.GroupBox();
            this.button_tabla = new System.Windows.Forms.Button();
            this.button_nadzor = new System.Windows.Forms.Button();
            this.button_odjava = new System.Windows.Forms.Button();
            this.button_upute = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.Opcije.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox_telefon);
            this.groupBox1.Controls.Add(this.textBox_mail);
            this.groupBox1.Controls.Add(this.textBox_pozicija);
            this.groupBox1.Controls.Add(this.textBox_ime);
            this.groupBox1.Location = new System.Drawing.Point(16, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(266, 173);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lični podaci";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 114);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Broj telefona";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 91);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "E-Mail";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 68);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Pozicija";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 46);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Ime i prezime";
            // 
            // textBox_telefon
            // 
            this.textBox_telefon.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.textBox_telefon.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox_telefon.Enabled = false;
            this.textBox_telefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_telefon.Location = new System.Drawing.Point(107, 114);
            this.textBox_telefon.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox_telefon.Name = "textBox_telefon";
            this.textBox_telefon.ReadOnly = true;
            this.textBox_telefon.Size = new System.Drawing.Size(128, 19);
            this.textBox_telefon.TabIndex = 7;
            // 
            // textBox_mail
            // 
            this.textBox_mail.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.textBox_mail.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox_mail.Enabled = false;
            this.textBox_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_mail.Location = new System.Drawing.Point(107, 91);
            this.textBox_mail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox_mail.Name = "textBox_mail";
            this.textBox_mail.ReadOnly = true;
            this.textBox_mail.Size = new System.Drawing.Size(128, 19);
            this.textBox_mail.TabIndex = 6;
            // 
            // textBox_pozicija
            // 
            this.textBox_pozicija.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.textBox_pozicija.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox_pozicija.Enabled = false;
            this.textBox_pozicija.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_pozicija.Location = new System.Drawing.Point(107, 68);
            this.textBox_pozicija.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox_pozicija.Name = "textBox_pozicija";
            this.textBox_pozicija.ReadOnly = true;
            this.textBox_pozicija.Size = new System.Drawing.Size(128, 19);
            this.textBox_pozicija.TabIndex = 5;
            // 
            // textBox_ime
            // 
            this.textBox_ime.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.textBox_ime.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox_ime.Enabled = false;
            this.textBox_ime.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_ime.Location = new System.Drawing.Point(107, 46);
            this.textBox_ime.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox_ime.Name = "textBox_ime";
            this.textBox_ime.ReadOnly = true;
            this.textBox_ime.Size = new System.Drawing.Size(128, 19);
            this.textBox_ime.TabIndex = 4;
            // 
            // Opcije
            // 
            this.Opcije.Controls.Add(this.button_tabla);
            this.Opcije.Controls.Add(this.button_nadzor);
            this.Opcije.Location = new System.Drawing.Point(299, 59);
            this.Opcije.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Opcije.Name = "Opcije";
            this.Opcije.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Opcije.Size = new System.Drawing.Size(276, 181);
            this.Opcije.TabIndex = 1;
            this.Opcije.TabStop = false;
            this.Opcije.Text = "Opcije";
            // 
            // button_tabla
            // 
            this.button_tabla.Location = new System.Drawing.Point(43, 111);
            this.button_tabla.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_tabla.Name = "button_tabla";
            this.button_tabla.Size = new System.Drawing.Size(200, 41);
            this.button_tabla.TabIndex = 1;
            this.button_tabla.Text = "Oglasna tabla";
            this.button_tabla.UseVisualStyleBackColor = true;
            this.button_tabla.Click += new System.EventHandler(this.button_tabla_Click);
            // 
            // button_nadzor
            // 
            this.button_nadzor.Location = new System.Drawing.Point(43, 41);
            this.button_nadzor.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_nadzor.Name = "button_nadzor";
            this.button_nadzor.Size = new System.Drawing.Size(200, 41);
            this.button_nadzor.TabIndex = 0;
            this.button_nadzor.Text = "Nadzor i upravljanje";
            this.button_nadzor.UseVisualStyleBackColor = true;
            this.button_nadzor.Click += new System.EventHandler(this.button_nadzor_Click);
            // 
            // button_odjava
            // 
            this.button_odjava.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_odjava.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_odjava.Location = new System.Drawing.Point(517, 10);
            this.button_odjava.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_odjava.Name = "button_odjava";
            this.button_odjava.Size = new System.Drawing.Size(67, 30);
            this.button_odjava.TabIndex = 5;
            this.button_odjava.Text = "ODJAVA";
            this.button_odjava.UseVisualStyleBackColor = false;
            this.button_odjava.Click += new System.EventHandler(this.button_odjava_Click);
            // 
            // button_upute
            // 
            this.button_upute.BackColor = System.Drawing.Color.DarkOrange;
            this.button_upute.Location = new System.Drawing.Point(50, 199);
            this.button_upute.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_upute.Name = "button_upute";
            this.button_upute.Size = new System.Drawing.Size(200, 41);
            this.button_upute.TabIndex = 2;
            this.button_upute.Text = "UPUTSTVO ZA KORIŠTENJE";
            this.button_upute.UseVisualStyleBackColor = false;
            this.button_upute.Click += new System.EventHandler(this.button_upute_Click);
            // 
            // Inzinjer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 262);
            this.Controls.Add(this.button_upute);
            this.Controls.Add(this.button_odjava);
            this.Controls.Add(this.Opcije);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Inzinjer";
            this.Text = "Inzinjer";
            this.Load += new System.EventHandler(this.Inzinjer_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Opcije.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox_telefon;
        private System.Windows.Forms.TextBox textBox_mail;
        private System.Windows.Forms.TextBox textBox_pozicija;
        private System.Windows.Forms.TextBox textBox_ime;
        private System.Windows.Forms.GroupBox Opcije;
        private System.Windows.Forms.Button button_odjava;
        private System.Windows.Forms.Button button_tabla;
        private System.Windows.Forms.Button button_nadzor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_upute;
    }
}