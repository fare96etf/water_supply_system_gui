﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DRAOS2_projekat_vodovod
{
    public partial class Pocetna : Form
    {
        static Klasa_Vodovod v;
        public Pocetna()
        {
            InitializeComponent();
            v = new Klasa_Vodovod();
            textBox_Ime.Select();
        }

        public Pocetna(Klasa_Vodovod vod)
        {
            InitializeComponent();
            v = vod;
            textBox_Ime.Select();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string un = textBox_Ime.Text;
            string pass = textBox_Sifra.Text;
            if (un == v.admin_username && pass == v.admin_password)
            {
                //otvoriti formu admin
                Admin forma_admin = new Admin(v);
                this.Hide();
                forma_admin.ShowDialog();
                this.Close();
            }
            else if (v.Pretrazi_Tehnologe(un, pass) != null)
            {
                //otvoriti formu tehnolog
                Klasa_Tehnolog tech_k = v.Pretrazi_Tehnologe(un, pass);
                Tehnolog tech = new Tehnolog(v, tech_k);
                this.Hide();
                tech.ShowDialog();
                this.Close();
            }
            else if (v.Pretrazi_Inzinjere(un, pass) != null)
            {
                //otvoriti formu inzinjer
                Klasa_Inzinjer eng_k = v.Pretrazi_Inzinjere(un, pass);
                Inzinjer eng = new Inzinjer(v, eng_k);
                this.Hide();
                eng.ShowDialog();
                this.Close();
            }
            else
            {
                //ispisati da nema korisnika u bazi
                toolStripStatusLabel_pocetna.Text = "Korisničko ime i šifra se ne poklapaju!";
            }
        }

        private void Pocetna_Load(object sender, EventArgs e)
        {
        }

        private void zatvori_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
