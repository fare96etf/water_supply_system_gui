﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DRAOS2_projekat_vodovod
{
    public class Klasa_Osoba
    {
        //atributi
        protected string ime;
        protected string pozicija;
        protected string mail;
        protected string telefon;
        protected string username;
        protected string password;
        public int id;
        static int iduci_ID = 0; 

        //konstruktori
        public Klasa_Osoba() 
        {
            ime = "Random";
            pozicija = "Tehnolog";
            mail = "tehnolog@vodovod.com";
            telefon = "123456";
            username = "techo";
            password = "123";
            id = iduci_ID;
            iduci_ID++;
        }
        public Klasa_Osoba (string i, string m, string tel, string un, string pass)
        {
            ime = i;
            mail = m;
            telefon = tel;
            username = un;
            password = pass;
            id = iduci_ID;
            iduci_ID++;
        }

        //getteri i setteri
        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }

        public string Pozicija
        {
            get { return pozicija; }
            set { pozicija = value; }
        }

        public string Mail
        {
            get { return mail; }
            set { mail = value; }
        }

        public string Telefon
        {
            get { return telefon; }
            set { telefon = value; }
        }

        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public int ID
        {
            get { return id; }
            set { id = value; }
        }


    }
}
