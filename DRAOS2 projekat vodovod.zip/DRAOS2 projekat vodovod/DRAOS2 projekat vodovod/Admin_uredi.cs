﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DRAOS2_projekat_vodovod
{
    public partial class Admin_uredi : Form
    {
        public Klasa_Vodovod v;
        public Klasa_Inzinjer eng;
        public Klasa_Tehnolog t;
        public Admin_uredi()
        {
            InitializeComponent();
        }

        public Admin_uredi(Klasa_Vodovod vod, Klasa_Inzinjer e)
        {
            InitializeComponent();
            v = vod;
            eng = e;
            textBox_ime.Text = eng.Ime;
            textBox_pozicija.Text = eng.Pozicija;
            textBox_mail.Text = eng.Mail;
            textBox_tel.Text = eng.Telefon;
            textBox_un.Text = eng.Username;
            textBox_pass.Text = eng.Password;
        }

        public Admin_uredi(Klasa_Vodovod vod, Klasa_Tehnolog tech)
        {
            InitializeComponent();
            v = vod;
            t = tech;
            textBox_ime.Text = tech.Ime;
            textBox_pozicija.Text = tech.Pozicija;
            textBox_mail.Text = tech.Mail;
            textBox_tel.Text = tech.Telefon;
            textBox_un.Text = tech.Username;
            textBox_pass.Text = tech.Password;
            toolStripStatusLabel_uredi.Text = "";
        }

        private void Admin_uredi_Load(object sender, EventArgs e)
        {

        }

        private void button_potvrda_Click(object sender, EventArgs e)
        {
            int provjera = 0;
            if (string.IsNullOrWhiteSpace(textBox_ime.Text)) provjera = 1;
            if (string.IsNullOrWhiteSpace(textBox_mail.Text)) provjera = 1;
            if (string.IsNullOrWhiteSpace(textBox_tel.Text)) provjera = 1;
            if (string.IsNullOrWhiteSpace(textBox_un.Text)) provjera = 1;
            if (string.IsNullOrWhiteSpace(textBox_pass.Text)) provjera = 1;
            if (eng != null && provjera == 0)
            {
                toolStripStatusLabel_uredi.Text = "";
                int ind = v.inzinjeri.FindIndex(x => x.id == eng.id);
                v.inzinjeri[ind].Ime = textBox_ime.Text;
                v.inzinjeri[ind].Pozicija = textBox_pozicija.Text;
                v.inzinjeri[ind].Mail = textBox_mail.Text;
                v.inzinjeri[ind].Telefon = textBox_tel.Text;
                v.inzinjeri[ind].Username = textBox_un.Text;
                v.inzinjeri[ind].Password = textBox_pass.Text;
                MessageBox.Show("Promjene su uspješno izvršene!", "OBAVIJEST");
            }
            if (t != null && provjera == 0)
            {
                toolStripStatusLabel_uredi.Text = "";
                int ind = v.tehnolozi.FindIndex(x => x.id == t.id);
                v.tehnolozi[ind].Ime = textBox_ime.Text;
                v.tehnolozi[ind].Pozicija = textBox_pozicija.Text;
                v.tehnolozi[ind].Mail = textBox_mail.Text;
                v.tehnolozi[ind].Telefon = textBox_tel.Text;
                v.tehnolozi[ind].Username = textBox_un.Text;
                v.tehnolozi[ind].Password = textBox_pass.Text;
                MessageBox.Show("Promjene su uspješno izvršene!", "OBAVIJEST");
            }
            

            if (provjera == 1)
            {
                toolStripStatusLabel_uredi.Text = "Pogrešan unos!";
            }
        }

        private void button_odjava_Click(object sender, EventArgs e)
        {
            Pocetna p = new Pocetna(v);
            this.Hide();
            p.ShowDialog();
            this.Close();
        }

        private void button_nazad_Click(object sender, EventArgs e)
        {
            Admin admin = new Admin(v);
            this.Hide();
            admin.ShowDialog();
            this.Close();
        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
