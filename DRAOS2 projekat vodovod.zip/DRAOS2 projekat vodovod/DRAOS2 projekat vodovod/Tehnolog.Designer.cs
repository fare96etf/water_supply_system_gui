﻿namespace DRAOS2_projekat_vodovod
{
    partial class Tehnolog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_odjava = new System.Windows.Forms.Button();
            this.Opcije = new System.Windows.Forms.GroupBox();
            this.button_tabla = new System.Windows.Forms.Button();
            this.button_nadzor = new System.Windows.Forms.Button();
            this.button_upute = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_telefon = new System.Windows.Forms.TextBox();
            this.textBox_mail = new System.Windows.Forms.TextBox();
            this.textBox_pozicija = new System.Windows.Forms.TextBox();
            this.textBox_ime = new System.Windows.Forms.TextBox();
            this.Opcije.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_odjava
            // 
            this.button_odjava.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_odjava.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_odjava.Location = new System.Drawing.Point(689, 12);
            this.button_odjava.Name = "button_odjava";
            this.button_odjava.Size = new System.Drawing.Size(89, 37);
            this.button_odjava.TabIndex = 8;
            this.button_odjava.Text = "ODJAVA";
            this.button_odjava.UseVisualStyleBackColor = false;
            this.button_odjava.Click += new System.EventHandler(this.button_odjava_Click);
            // 
            // Opcije
            // 
            this.Opcije.Controls.Add(this.button_tabla);
            this.Opcije.Controls.Add(this.button_nadzor);
            this.Opcije.Location = new System.Drawing.Point(399, 73);
            this.Opcije.Name = "Opcije";
            this.Opcije.Size = new System.Drawing.Size(368, 223);
            this.Opcije.TabIndex = 7;
            this.Opcije.TabStop = false;
            this.Opcije.Text = "Opcije";
            // 
            // button_tabla
            // 
            this.button_tabla.Location = new System.Drawing.Point(57, 137);
            this.button_tabla.Name = "button_tabla";
            this.button_tabla.Size = new System.Drawing.Size(266, 51);
            this.button_tabla.TabIndex = 3;
            this.button_tabla.Text = "Oglasna tabla";
            this.button_tabla.UseVisualStyleBackColor = true;
            this.button_tabla.Click += new System.EventHandler(this.button_tabla_Click);
            // 
            // button_nadzor
            // 
            this.button_nadzor.Location = new System.Drawing.Point(57, 51);
            this.button_nadzor.Name = "button_nadzor";
            this.button_nadzor.Size = new System.Drawing.Size(266, 51);
            this.button_nadzor.TabIndex = 2;
            this.button_nadzor.Text = "Nadzor";
            this.button_nadzor.UseVisualStyleBackColor = true;
            this.button_nadzor.Click += new System.EventHandler(this.button_nadzor_Click);
            // 
            // button_upute
            // 
            this.button_upute.BackColor = System.Drawing.Color.DarkOrange;
            this.button_upute.Location = new System.Drawing.Point(67, 245);
            this.button_upute.Name = "button_upute";
            this.button_upute.Size = new System.Drawing.Size(266, 51);
            this.button_upute.TabIndex = 10;
            this.button_upute.Text = "UPUTSTVO ZA KORIŠTENJE";
            this.button_upute.UseVisualStyleBackColor = false;
            this.button_upute.Click += new System.EventHandler(this.button_upute_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox_telefon);
            this.groupBox1.Controls.Add(this.textBox_mail);
            this.groupBox1.Controls.Add(this.textBox_pozicija);
            this.groupBox1.Controls.Add(this.textBox_ime);
            this.groupBox1.Location = new System.Drawing.Point(21, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(354, 213);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lični podaci";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "Broj telefona";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "E-Mail";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Pozicija";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "Ime i prezime";
            // 
            // textBox_telefon
            // 
            this.textBox_telefon.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox_telefon.Enabled = false;
            this.textBox_telefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_telefon.Location = new System.Drawing.Point(143, 140);
            this.textBox_telefon.Name = "textBox_telefon";
            this.textBox_telefon.ReadOnly = true;
            this.textBox_telefon.Size = new System.Drawing.Size(169, 22);
            this.textBox_telefon.TabIndex = 7;
            // 
            // textBox_mail
            // 
            this.textBox_mail.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox_mail.Enabled = false;
            this.textBox_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_mail.Location = new System.Drawing.Point(143, 112);
            this.textBox_mail.Name = "textBox_mail";
            this.textBox_mail.ReadOnly = true;
            this.textBox_mail.Size = new System.Drawing.Size(169, 22);
            this.textBox_mail.TabIndex = 6;
            // 
            // textBox_pozicija
            // 
            this.textBox_pozicija.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox_pozicija.Enabled = false;
            this.textBox_pozicija.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_pozicija.Location = new System.Drawing.Point(143, 84);
            this.textBox_pozicija.Name = "textBox_pozicija";
            this.textBox_pozicija.ReadOnly = true;
            this.textBox_pozicija.Size = new System.Drawing.Size(169, 22);
            this.textBox_pozicija.TabIndex = 5;
            // 
            // textBox_ime
            // 
            this.textBox_ime.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox_ime.Enabled = false;
            this.textBox_ime.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_ime.Location = new System.Drawing.Point(143, 56);
            this.textBox_ime.Name = "textBox_ime";
            this.textBox_ime.ReadOnly = true;
            this.textBox_ime.Size = new System.Drawing.Size(169, 22);
            this.textBox_ime.TabIndex = 4;
            // 
            // Tehnolog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 323);
            this.Controls.Add(this.button_upute);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button_odjava);
            this.Controls.Add(this.Opcije);
            this.Name = "Tehnolog";
            this.Text = "Tehnolog";
            this.Load += new System.EventHandler(this.Tehnolog_Load);
            this.Opcije.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_odjava;
        private System.Windows.Forms.GroupBox Opcije;
        private System.Windows.Forms.Button button_tabla;
        private System.Windows.Forms.Button button_nadzor;
        private System.Windows.Forms.Button button_upute;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_telefon;
        private System.Windows.Forms.TextBox textBox_mail;
        private System.Windows.Forms.TextBox textBox_pozicija;
        private System.Windows.Forms.TextBox textBox_ime;
    }
}