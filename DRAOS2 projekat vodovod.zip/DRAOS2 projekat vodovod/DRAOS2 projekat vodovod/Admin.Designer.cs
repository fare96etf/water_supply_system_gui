﻿namespace DRAOS2_projekat_vodovod
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_odjava = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button_dodaj = new System.Windows.Forms.Button();
            this.button_uredi = new System.Windows.Forms.Button();
            this.button_obrisi = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.button_teh = new System.Windows.Forms.Button();
            this.button_ing = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_odjava
            // 
            this.button_odjava.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_odjava.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_odjava.Location = new System.Drawing.Point(524, 10);
            this.button_odjava.Margin = new System.Windows.Forms.Padding(2);
            this.button_odjava.Name = "button_odjava";
            this.button_odjava.Size = new System.Drawing.Size(67, 30);
            this.button_odjava.TabIndex = 4;
            this.button_odjava.Text = "ODJAVA";
            this.button_odjava.UseVisualStyleBackColor = false;
            this.button_odjava.Click += new System.EventHandler(this.button4_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 45);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(579, 380);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.button_dodaj);
            this.tabPage1.Controls.Add(this.button_uredi);
            this.tabPage1.Controls.Add(this.button_obrisi);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(571, 354);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Korisnici";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7});
            this.dataGridView1.Location = new System.Drawing.Point(17, 28);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(537, 265);
            this.dataGridView1.TabIndex = 8;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Ime i prezime";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column1.Width = 200;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Status";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "E-Mail";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Broj telefona";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Korisničko ime";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Šifra";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "ID";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // button_dodaj
            // 
            this.button_dodaj.Location = new System.Drawing.Point(147, 302);
            this.button_dodaj.Margin = new System.Windows.Forms.Padding(2);
            this.button_dodaj.Name = "button_dodaj";
            this.button_dodaj.Size = new System.Drawing.Size(96, 39);
            this.button_dodaj.TabIndex = 7;
            this.button_dodaj.Text = "Dodaj novog korisnika";
            this.button_dodaj.UseVisualStyleBackColor = true;
            this.button_dodaj.Click += new System.EventHandler(this.button_dodaj_Click);
            // 
            // button_uredi
            // 
            this.button_uredi.Location = new System.Drawing.Point(247, 302);
            this.button_uredi.Margin = new System.Windows.Forms.Padding(2);
            this.button_uredi.Name = "button_uredi";
            this.button_uredi.Size = new System.Drawing.Size(96, 39);
            this.button_uredi.TabIndex = 6;
            this.button_uredi.Text = "Uredi podatke";
            this.button_uredi.UseVisualStyleBackColor = true;
            this.button_uredi.Click += new System.EventHandler(this.button_uredi_Click_1);
            // 
            // button_obrisi
            // 
            this.button_obrisi.Location = new System.Drawing.Point(347, 302);
            this.button_obrisi.Margin = new System.Windows.Forms.Padding(2);
            this.button_obrisi.Name = "button_obrisi";
            this.button_obrisi.Size = new System.Drawing.Size(96, 39);
            this.button_obrisi.TabIndex = 5;
            this.button_obrisi.Text = "Obriši korisnika";
            this.button_obrisi.UseVisualStyleBackColor = true;
            this.button_obrisi.Click += new System.EventHandler(this.button_obrisi_Click_1);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button_ing);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.button_teh);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(571, 354);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Pregled aplikacije";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button1.Location = new System.Drawing.Point(222, 194);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 39);
            this.button1.TabIndex = 8;
            this.button1.Text = "OGLASNA TABLA";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_teh
            // 
            this.button_teh.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_teh.Location = new System.Drawing.Point(135, 102);
            this.button_teh.Margin = new System.Windows.Forms.Padding(2);
            this.button_teh.Name = "button_teh";
            this.button_teh.Size = new System.Drawing.Size(96, 39);
            this.button_teh.TabIndex = 7;
            this.button_teh.Text = "TEHNOLOG";
            this.button_teh.UseVisualStyleBackColor = false;
            this.button_teh.Click += new System.EventHandler(this.button_teh_Click);
            // 
            // button_ing
            // 
            this.button_ing.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_ing.Location = new System.Drawing.Point(314, 102);
            this.button_ing.Margin = new System.Windows.Forms.Padding(2);
            this.button_ing.Name = "button_ing";
            this.button_ing.Size = new System.Drawing.Size(96, 39);
            this.button_ing.TabIndex = 9;
            this.button_ing.Text = "INŽINJER";
            this.button_ing.UseVisualStyleBackColor = false;
            this.button_ing.Click += new System.EventHandler(this.button_ing_Click_1);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(621, 438);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button_odjava);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Admin";
            this.Text = "Administrator";
            this.Load += new System.EventHandler(this.Admin_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button_odjava;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.Button button_dodaj;
        private System.Windows.Forms.Button button_uredi;
        private System.Windows.Forms.Button button_obrisi;
        private System.Windows.Forms.Button button_teh;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button_ing;
    }
}