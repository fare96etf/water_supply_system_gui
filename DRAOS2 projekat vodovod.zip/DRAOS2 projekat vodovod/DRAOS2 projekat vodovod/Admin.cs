﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DRAOS2_projekat_vodovod
{
    public partial class Admin : Form
    {
        public Klasa_Vodovod v;
        public Admin()
        {
            InitializeComponent();
        }

        public Admin(Klasa_Vodovod vod)
        {
            InitializeComponent();
            v = vod;
            foreach (Klasa_Inzinjer eng in v.inzinjeri)
            {
                dataGridView1.Rows.Add(eng.Ime, eng.Pozicija, eng.Mail, eng.Telefon, eng.Username, eng.Password, eng.ID.ToString());
            }
            foreach (Klasa_Tehnolog tech in v.tehnolozi)
            {
                dataGridView1.Rows.Add(tech.Ime, tech.Pozicija, tech.Mail, tech.Telefon, tech.Username, tech.Password, tech.ID.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Pocetna p = new Pocetna(v);
            this.Hide();
            p.ShowDialog();
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void Admin_Load(object sender, EventArgs e)
        {

        }

      

        private void button_obrisi_Click_1(object sender, EventArgs e)
        {
            int selektirano = dataGridView1.SelectedCells.Count;
            for (int i = 0; i < selektirano; i++)
            {

                int red_index = dataGridView1.SelectedCells[i].RowIndex;
                DataGridViewRow red = dataGridView1.Rows[red_index];
                string ime = Convert.ToString(red.Cells["Column1"].Value);
                string poz = Convert.ToString(red.Cells["Column2"].Value);

                if (poz == "Inžinjer")
                {
                    v.inzinjeri.RemoveAt(v.inzinjeri.FindIndex(x => x.Ime == ime));
                }
                if (poz == "Tehnolog")
                {
                    v.tehnolozi.RemoveAt(v.tehnolozi.FindIndex(x => x.Ime == ime));
                }

            }
            dataGridView1.Rows.Clear();
            foreach (Klasa_Inzinjer eng in v.inzinjeri)
            {
                dataGridView1.Rows.Add(eng.Ime, eng.Pozicija, eng.Mail, eng.Telefon, eng.Username, eng.Password, eng.ID.ToString());
            }
            foreach (Klasa_Tehnolog tech in v.tehnolozi)
            {
                dataGridView1.Rows.Add(tech.Ime, tech.Pozicija, tech.Mail, tech.Telefon, tech.Username, tech.Password, tech.ID.ToString());
            }
        }

        private void button_uredi_Click_1(object sender, EventArgs e)
        {
            int selektirano = dataGridView1.SelectedCells.Count;
            if (selektirano == 1)
            {
                int red_index = dataGridView1.SelectedCells[0].RowIndex;
                DataGridViewRow red = dataGridView1.Rows[red_index];
                string ime = Convert.ToString(red.Cells["Column1"].Value);
                string poz = Convert.ToString(red.Cells["Column2"].Value);

                if (poz == "Inžinjer")
                {
                    Admin_uredi au = new Admin_uredi(v, v.inzinjeri[v.inzinjeri.FindIndex(x => x.Ime == ime)]);
                    this.Hide();
                    au.ShowDialog();
                    this.Close();

                }
                if (poz == "Tehnolog")
                {
                    Admin_uredi au = new Admin_uredi(v, v.tehnolozi[v.tehnolozi.FindIndex(x => x.Ime == ime)]);
                    this.Hide();
                    au.ShowDialog();
                    this.Close();
                }
            }
        }

        private void button_teh_Click(object sender, EventArgs e)
        {
            Nadzor u = new Nadzor(v);
            this.Hide();
            u.ShowDialog();
            this.Close();
        }


        private void button_dodaj_Click(object sender, EventArgs e)
        {
            Admin_dodaj ad = new Admin_dodaj(v);
            this.Hide();
            ad.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OglasnaTabla o = new OglasnaTabla(v);
            this.Hide();
            o.ShowDialog();
            this.Close();
        }

        private void button_ing_Click_1(object sender, EventArgs e)
        {
            Upravljanje u = new Upravljanje(v);
            this.Hide();
            u.ShowDialog();
            this.Close();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }
    }
}
