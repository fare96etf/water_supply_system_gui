﻿namespace DRAOS2_projekat_vodovod
{
    partial class Nadzor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Nadzor));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.label_status_ime = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button_odjava = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox_pp = new System.Windows.Forms.GroupBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox_protok = new System.Windows.Forms.TextBox();
            this.textBox_pritisak = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox_nivo = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox_ph = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_trenutno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton_p2 = new System.Windows.Forms.RadioButton();
            this.radioButton_p1 = new System.Windows.Forms.RadioButton();
            this.radioButton_v2 = new System.Windows.Forms.RadioButton();
            this.radioButton_v1 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.radioButton_prit_ph = new System.Windows.Forms.RadioButton();
            this.radioButton_prot_nivo = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.radioButton_hp2 = new System.Windows.Forms.RadioButton();
            this.radioButton_hp1 = new System.Windows.Forms.RadioButton();
            this.radioButton_hv2 = new System.Windows.Forms.RadioButton();
            this.radioButton_hv1 = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBox_ph_prom = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_nivo_srednja = new System.Windows.Forms.TextBox();
            this.textBox_nivo_max = new System.Windows.Forms.TextBox();
            this.textBox_ph_min = new System.Windows.Forms.TextBox();
            this.textBox_nivo_min = new System.Windows.Forms.TextBox();
            this.textBox_ph_max = new System.Windows.Forms.TextBox();
            this.textBox_nivo_prom = new System.Windows.Forms.TextBox();
            this.textBox_ph_srednja = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox_dnevna = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_pritisak_prom = new System.Windows.Forms.TextBox();
            this.textBox_pritisak_min = new System.Windows.Forms.TextBox();
            this.textBox_pritisak_max = new System.Windows.Forms.TextBox();
            this.textBox_pritisak_srednja = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_protok_prom = new System.Windows.Forms.TextBox();
            this.textBox_protok_min = new System.Windows.Forms.TextBox();
            this.textBox_protok_max = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_protok_srednja = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox_graf = new System.Windows.Forms.GroupBox();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox_pp.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox_dnevna.SuspendLayout();
            this.groupBox_graf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.SuspendLayout();
            // 
            // label_status_ime
            // 
            this.label_status_ime.AutoSize = true;
            this.label_status_ime.Location = new System.Drawing.Point(458, 13);
            this.label_status_ime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_status_ime.Name = "label_status_ime";
            this.label_status_ime.Size = new System.Drawing.Size(94, 13);
            this.label_status_ime.TabIndex = 17;
            this.label_status_ime.Text = "Status i Ime osobe";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(581, 5);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(67, 30);
            this.button3.TabIndex = 15;
            this.button3.Text = "NAZAD";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button_odjava
            // 
            this.button_odjava.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_odjava.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_odjava.Location = new System.Drawing.Point(662, 5);
            this.button_odjava.Margin = new System.Windows.Forms.Padding(2);
            this.button_odjava.Name = "button_odjava";
            this.button_odjava.Size = new System.Drawing.Size(67, 30);
            this.button_odjava.TabIndex = 14;
            this.button_odjava.Text = "ODJAVA";
            this.button_odjava.UseVisualStyleBackColor = false;
            this.button_odjava.Click += new System.EventHandler(this.button_odjava_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.tabControl1.ItemSize = new System.Drawing.Size(80, 30);
            this.tabControl1.Location = new System.Drawing.Point(3, 13);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(736, 630);
            this.tabControl1.TabIndex = 13;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 34);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(728, 592);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Nadzor i upravljanje";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox_pp);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Location = new System.Drawing.Point(300, 410);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(424, 178);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Izlazne veličine ";
            // 
            // groupBox_pp
            // 
            this.groupBox_pp.Controls.Add(this.textBox8);
            this.groupBox_pp.Controls.Add(this.textBox6);
            this.groupBox_pp.Controls.Add(this.textBox_protok);
            this.groupBox_pp.Controls.Add(this.textBox_pritisak);
            this.groupBox_pp.Location = new System.Drawing.Point(18, 40);
            this.groupBox_pp.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_pp.Name = "groupBox_pp";
            this.groupBox_pp.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_pp.Size = new System.Drawing.Size(175, 117);
            this.groupBox_pp.TabIndex = 14;
            this.groupBox_pp.TabStop = false;
            this.groupBox_pp.Text = "VENTIL 1";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(14, 41);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(76, 21);
            this.textBox8.TabIndex = 4;
            this.textBox8.Text = "Protok";
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(14, 77);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(76, 21);
            this.textBox6.TabIndex = 6;
            this.textBox6.Text = "Pritisak";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_protok
            // 
            this.textBox_protok.Location = new System.Drawing.Point(93, 41);
            this.textBox_protok.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_protok.Name = "textBox_protok";
            this.textBox_protok.Size = new System.Drawing.Size(76, 21);
            this.textBox_protok.TabIndex = 8;
            // 
            // textBox_pritisak
            // 
            this.textBox_pritisak.Location = new System.Drawing.Point(93, 77);
            this.textBox_pritisak.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_pritisak.Name = "textBox_pritisak";
            this.textBox_pritisak.Size = new System.Drawing.Size(76, 21);
            this.textBox_pritisak.TabIndex = 10;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox5);
            this.groupBox4.Controls.Add(this.textBox_nivo);
            this.groupBox4.Controls.Add(this.textBox7);
            this.groupBox4.Controls.Add(this.textBox_ph);
            this.groupBox4.Location = new System.Drawing.Point(213, 40);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(173, 117);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "REZERVOAR";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(14, 37);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(76, 21);
            this.textBox5.TabIndex = 7;
            this.textBox5.Text = "Nivo";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_nivo
            // 
            this.textBox_nivo.Location = new System.Drawing.Point(94, 37);
            this.textBox_nivo.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_nivo.Name = "textBox_nivo";
            this.textBox_nivo.Size = new System.Drawing.Size(76, 21);
            this.textBox_nivo.TabIndex = 11;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(14, 72);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(76, 21);
            this.textBox7.TabIndex = 5;
            this.textBox7.Text = "pH";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_ph
            // 
            this.textBox_ph.Location = new System.Drawing.Point(94, 72);
            this.textBox_ph.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_ph.Name = "textBox_ph";
            this.textBox_ph.Size = new System.Drawing.Size(76, 21);
            this.textBox_ph.TabIndex = 9;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.textBox_trenutno);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.radioButton_p2);
            this.groupBox2.Controls.Add(this.radioButton_p1);
            this.groupBox2.Controls.Add(this.radioButton_v2);
            this.groupBox2.Controls.Add(this.radioButton_v1);
            this.groupBox2.Location = new System.Drawing.Point(6, 410);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(274, 178);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ulazne veličine ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(228, 96);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "%";
            // 
            // textBox_trenutno
            // 
            this.textBox_trenutno.Location = new System.Drawing.Point(147, 93);
            this.textBox_trenutno.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_trenutno.Name = "textBox_trenutno";
            this.textBox_trenutno.ReadOnly = true;
            this.textBox_trenutno.Size = new System.Drawing.Size(76, 21);
            this.textBox_trenutno.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(135, 50);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "Trenutna vrijednost";
            // 
            // radioButton_p2
            // 
            this.radioButton_p2.AutoSize = true;
            this.radioButton_p2.Location = new System.Drawing.Point(22, 108);
            this.radioButton_p2.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_p2.Name = "radioButton_p2";
            this.radioButton_p2.Size = new System.Drawing.Size(82, 19);
            this.radioButton_p2.TabIndex = 3;
            this.radioButton_p2.TabStop = true;
            this.radioButton_p2.Text = "Pumpa 2";
            this.radioButton_p2.UseVisualStyleBackColor = true;
            this.radioButton_p2.CheckedChanged += new System.EventHandler(this.radioButton_p2_CheckedChanged);
            // 
            // radioButton_p1
            // 
            this.radioButton_p1.AutoSize = true;
            this.radioButton_p1.Location = new System.Drawing.Point(22, 85);
            this.radioButton_p1.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_p1.Name = "radioButton_p1";
            this.radioButton_p1.Size = new System.Drawing.Size(82, 19);
            this.radioButton_p1.TabIndex = 2;
            this.radioButton_p1.TabStop = true;
            this.radioButton_p1.Text = "Pumpa 1";
            this.radioButton_p1.UseVisualStyleBackColor = true;
            this.radioButton_p1.CheckedChanged += new System.EventHandler(this.radioButton_p1_CheckedChanged);
            // 
            // radioButton_v2
            // 
            this.radioButton_v2.AutoSize = true;
            this.radioButton_v2.Location = new System.Drawing.Point(22, 63);
            this.radioButton_v2.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_v2.Name = "radioButton_v2";
            this.radioButton_v2.Size = new System.Drawing.Size(73, 19);
            this.radioButton_v2.TabIndex = 1;
            this.radioButton_v2.TabStop = true;
            this.radioButton_v2.Text = "Ventil 2";
            this.radioButton_v2.UseVisualStyleBackColor = true;
            this.radioButton_v2.CheckedChanged += new System.EventHandler(this.radioButton_v2_CheckedChanged);
            // 
            // radioButton_v1
            // 
            this.radioButton_v1.AutoSize = true;
            this.radioButton_v1.Location = new System.Drawing.Point(22, 40);
            this.radioButton_v1.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_v1.Name = "radioButton_v1";
            this.radioButton_v1.Size = new System.Drawing.Size(73, 19);
            this.radioButton_v1.TabIndex = 0;
            this.radioButton_v1.TabStop = true;
            this.radioButton_v1.Text = "Ventil 1";
            this.radioButton_v1.UseVisualStyleBackColor = true;
            this.radioButton_v1.CheckedChanged += new System.EventHandler(this.radioButton_v1_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox1.BackgroundImage")));
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Location = new System.Drawing.Point(2, 5);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(720, 380);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sistem";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Red;
            this.button6.Location = new System.Drawing.Point(7, 322);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(92, 39);
            this.button6.TabIndex = 10;
            this.button6.Text = "SAFE MODE";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox_graf);
            this.tabPage2.Location = new System.Drawing.Point(4, 34);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(728, 539);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Historija";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.radioButton_prit_ph);
            this.groupBox9.Controls.Add(this.radioButton_prot_nivo);
            this.groupBox9.Location = new System.Drawing.Point(30, 181);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox9.Size = new System.Drawing.Size(140, 81);
            this.groupBox9.TabIndex = 7;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Grafik";
            // 
            // radioButton_prit_ph
            // 
            this.radioButton_prit_ph.AutoSize = true;
            this.radioButton_prit_ph.Location = new System.Drawing.Point(24, 50);
            this.radioButton_prit_ph.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_prit_ph.Name = "radioButton_prit_ph";
            this.radioButton_prit_ph.Size = new System.Drawing.Size(73, 19);
            this.radioButton_prit_ph.TabIndex = 7;
            this.radioButton_prit_ph.TabStop = true;
            this.radioButton_prit_ph.Text = "Pritisak";
            this.radioButton_prit_ph.UseVisualStyleBackColor = true;
            this.radioButton_prit_ph.CheckedChanged += new System.EventHandler(this.radioButton_prit_ph_CheckedChanged);
            // 
            // radioButton_prot_nivo
            // 
            this.radioButton_prot_nivo.AutoSize = true;
            this.radioButton_prot_nivo.Location = new System.Drawing.Point(24, 27);
            this.radioButton_prot_nivo.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_prot_nivo.Name = "radioButton_prot_nivo";
            this.radioButton_prot_nivo.Size = new System.Drawing.Size(66, 19);
            this.radioButton_prot_nivo.TabIndex = 6;
            this.radioButton_prot_nivo.TabStop = true;
            this.radioButton_prot_nivo.Text = "Protok";
            this.radioButton_prot_nivo.UseVisualStyleBackColor = true;
            this.radioButton_prot_nivo.CheckedChanged += new System.EventHandler(this.radioButton_prot_nivo_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.radioButton_hp2);
            this.groupBox6.Controls.Add(this.radioButton_hp1);
            this.groupBox6.Controls.Add(this.radioButton_hv2);
            this.groupBox6.Controls.Add(this.radioButton_hv1);
            this.groupBox6.Location = new System.Drawing.Point(30, 20);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox6.Size = new System.Drawing.Size(140, 153);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Veličine";
            // 
            // radioButton_hp2
            // 
            this.radioButton_hp2.AutoSize = true;
            this.radioButton_hp2.Location = new System.Drawing.Point(24, 104);
            this.radioButton_hp2.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_hp2.Name = "radioButton_hp2";
            this.radioButton_hp2.Size = new System.Drawing.Size(82, 19);
            this.radioButton_hp2.TabIndex = 7;
            this.radioButton_hp2.TabStop = true;
            this.radioButton_hp2.Text = "Pumpa 2";
            this.radioButton_hp2.UseVisualStyleBackColor = true;
            this.radioButton_hp2.CheckedChanged += new System.EventHandler(this.radioButton_hp2_CheckedChanged);
            // 
            // radioButton_hp1
            // 
            this.radioButton_hp1.AutoSize = true;
            this.radioButton_hp1.Location = new System.Drawing.Point(24, 82);
            this.radioButton_hp1.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_hp1.Name = "radioButton_hp1";
            this.radioButton_hp1.Size = new System.Drawing.Size(82, 19);
            this.radioButton_hp1.TabIndex = 6;
            this.radioButton_hp1.TabStop = true;
            this.radioButton_hp1.Text = "Pumpa 1";
            this.radioButton_hp1.UseVisualStyleBackColor = true;
            this.radioButton_hp1.CheckedChanged += new System.EventHandler(this.radioButton_hp1_CheckedChanged);
            // 
            // radioButton_hv2
            // 
            this.radioButton_hv2.AutoSize = true;
            this.radioButton_hv2.Location = new System.Drawing.Point(24, 59);
            this.radioButton_hv2.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_hv2.Name = "radioButton_hv2";
            this.radioButton_hv2.Size = new System.Drawing.Size(73, 19);
            this.radioButton_hv2.TabIndex = 5;
            this.radioButton_hv2.TabStop = true;
            this.radioButton_hv2.Text = "Ventil 2";
            this.radioButton_hv2.UseVisualStyleBackColor = true;
            this.radioButton_hv2.CheckedChanged += new System.EventHandler(this.radioButton_hv2_CheckedChanged);
            // 
            // radioButton_hv1
            // 
            this.radioButton_hv1.AutoSize = true;
            this.radioButton_hv1.Location = new System.Drawing.Point(24, 36);
            this.radioButton_hv1.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_hv1.Name = "radioButton_hv1";
            this.radioButton_hv1.Size = new System.Drawing.Size(73, 19);
            this.radioButton_hv1.TabIndex = 4;
            this.radioButton_hv1.TabStop = true;
            this.radioButton_hv1.Text = "Ventil 1";
            this.radioButton_hv1.UseVisualStyleBackColor = true;
            this.radioButton_hv1.CheckedChanged += new System.EventHandler(this.radioButton_hv1_CheckedChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.groupBox5);
            this.groupBox7.Controls.Add(this.groupBox_dnevna);
            this.groupBox7.Location = new System.Drawing.Point(11, 287);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox7.Size = new System.Drawing.Size(699, 248);
            this.groupBox7.TabIndex = 5;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Dnevna statistika";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBox_ph_prom);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.textBox_nivo_srednja);
            this.groupBox5.Controls.Add(this.textBox_nivo_max);
            this.groupBox5.Controls.Add(this.textBox_ph_min);
            this.groupBox5.Controls.Add(this.textBox_nivo_min);
            this.groupBox5.Controls.Add(this.textBox_ph_max);
            this.groupBox5.Controls.Add(this.textBox_nivo_prom);
            this.groupBox5.Controls.Add(this.textBox_ph_srednja);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Location = new System.Drawing.Point(415, 34);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(279, 201);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "REZERVOAR";
            // 
            // textBox_ph_prom
            // 
            this.textBox_ph_prom.Location = new System.Drawing.Point(169, 164);
            this.textBox_ph_prom.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_ph_prom.Name = "textBox_ph_prom";
            this.textBox_ph_prom.Size = new System.Drawing.Size(76, 21);
            this.textBox_ph_prom.TabIndex = 22;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(191, 22);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(25, 15);
            this.label10.TabIndex = 23;
            this.label10.Text = "pH";
            // 
            // textBox_nivo_srednja
            // 
            this.textBox_nivo_srednja.Location = new System.Drawing.Point(35, 64);
            this.textBox_nivo_srednja.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_nivo_srednja.Name = "textBox_nivo_srednja";
            this.textBox_nivo_srednja.Size = new System.Drawing.Size(76, 21);
            this.textBox_nivo_srednja.TabIndex = 14;
            // 
            // textBox_nivo_max
            // 
            this.textBox_nivo_max.Location = new System.Drawing.Point(35, 98);
            this.textBox_nivo_max.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_nivo_max.Name = "textBox_nivo_max";
            this.textBox_nivo_max.Size = new System.Drawing.Size(76, 21);
            this.textBox_nivo_max.TabIndex = 15;
            // 
            // textBox_ph_min
            // 
            this.textBox_ph_min.Location = new System.Drawing.Point(169, 131);
            this.textBox_ph_min.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_ph_min.Name = "textBox_ph_min";
            this.textBox_ph_min.Size = new System.Drawing.Size(76, 21);
            this.textBox_ph_min.TabIndex = 21;
            // 
            // textBox_nivo_min
            // 
            this.textBox_nivo_min.Location = new System.Drawing.Point(35, 131);
            this.textBox_nivo_min.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_nivo_min.Name = "textBox_nivo_min";
            this.textBox_nivo_min.Size = new System.Drawing.Size(76, 21);
            this.textBox_nivo_min.TabIndex = 16;
            // 
            // textBox_ph_max
            // 
            this.textBox_ph_max.Location = new System.Drawing.Point(169, 98);
            this.textBox_ph_max.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_ph_max.Name = "textBox_ph_max";
            this.textBox_ph_max.Size = new System.Drawing.Size(76, 21);
            this.textBox_ph_max.TabIndex = 20;
            // 
            // textBox_nivo_prom
            // 
            this.textBox_nivo_prom.Location = new System.Drawing.Point(35, 164);
            this.textBox_nivo_prom.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_nivo_prom.Name = "textBox_nivo_prom";
            this.textBox_nivo_prom.Size = new System.Drawing.Size(76, 21);
            this.textBox_nivo_prom.TabIndex = 17;
            // 
            // textBox_ph_srednja
            // 
            this.textBox_ph_srednja.Location = new System.Drawing.Point(169, 64);
            this.textBox_ph_srednja.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_ph_srednja.Name = "textBox_ph_srednja";
            this.textBox_ph_srednja.Size = new System.Drawing.Size(76, 21);
            this.textBox_ph_srednja.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(50, 22);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 15);
            this.label9.TabIndex = 18;
            this.label9.Text = "NIVO";
            // 
            // groupBox_dnevna
            // 
            this.groupBox_dnevna.Controls.Add(this.label8);
            this.groupBox_dnevna.Controls.Add(this.textBox_pritisak_prom);
            this.groupBox_dnevna.Controls.Add(this.textBox_pritisak_min);
            this.groupBox_dnevna.Controls.Add(this.textBox_pritisak_max);
            this.groupBox_dnevna.Controls.Add(this.textBox_pritisak_srednja);
            this.groupBox_dnevna.Controls.Add(this.label7);
            this.groupBox_dnevna.Controls.Add(this.textBox_protok_prom);
            this.groupBox_dnevna.Controls.Add(this.textBox_protok_min);
            this.groupBox_dnevna.Controls.Add(this.textBox_protok_max);
            this.groupBox_dnevna.Controls.Add(this.label6);
            this.groupBox_dnevna.Controls.Add(this.textBox_protok_srednja);
            this.groupBox_dnevna.Controls.Add(this.label4);
            this.groupBox_dnevna.Controls.Add(this.label3);
            this.groupBox_dnevna.Controls.Add(this.label2);
            this.groupBox_dnevna.Location = new System.Drawing.Point(5, 34);
            this.groupBox_dnevna.Name = "groupBox_dnevna";
            this.groupBox_dnevna.Size = new System.Drawing.Size(394, 201);
            this.groupBox_dnevna.TabIndex = 5;
            this.groupBox_dnevna.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(309, 21);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 15);
            this.label8.TabIndex = 27;
            this.label8.Text = "PRITISAK";
            // 
            // textBox_pritisak_prom
            // 
            this.textBox_pritisak_prom.Location = new System.Drawing.Point(304, 165);
            this.textBox_pritisak_prom.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_pritisak_prom.Name = "textBox_pritisak_prom";
            this.textBox_pritisak_prom.Size = new System.Drawing.Size(76, 21);
            this.textBox_pritisak_prom.TabIndex = 26;
            // 
            // textBox_pritisak_min
            // 
            this.textBox_pritisak_min.Location = new System.Drawing.Point(304, 132);
            this.textBox_pritisak_min.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_pritisak_min.Name = "textBox_pritisak_min";
            this.textBox_pritisak_min.Size = new System.Drawing.Size(76, 21);
            this.textBox_pritisak_min.TabIndex = 25;
            // 
            // textBox_pritisak_max
            // 
            this.textBox_pritisak_max.Location = new System.Drawing.Point(304, 99);
            this.textBox_pritisak_max.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_pritisak_max.Name = "textBox_pritisak_max";
            this.textBox_pritisak_max.Size = new System.Drawing.Size(76, 21);
            this.textBox_pritisak_max.TabIndex = 24;
            // 
            // textBox_pritisak_srednja
            // 
            this.textBox_pritisak_srednja.Location = new System.Drawing.Point(304, 65);
            this.textBox_pritisak_srednja.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_pritisak_srednja.Name = "textBox_pritisak_srednja";
            this.textBox_pritisak_srednja.Size = new System.Drawing.Size(76, 21);
            this.textBox_pritisak_srednja.TabIndex = 23;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(177, 22);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 15);
            this.label7.TabIndex = 22;
            this.label7.Text = "PROTOK";
            // 
            // textBox_protok_prom
            // 
            this.textBox_protok_prom.Location = new System.Drawing.Point(172, 166);
            this.textBox_protok_prom.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_protok_prom.Name = "textBox_protok_prom";
            this.textBox_protok_prom.Size = new System.Drawing.Size(76, 21);
            this.textBox_protok_prom.TabIndex = 21;
            // 
            // textBox_protok_min
            // 
            this.textBox_protok_min.Location = new System.Drawing.Point(172, 134);
            this.textBox_protok_min.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_protok_min.Name = "textBox_protok_min";
            this.textBox_protok_min.Size = new System.Drawing.Size(76, 21);
            this.textBox_protok_min.TabIndex = 20;
            // 
            // textBox_protok_max
            // 
            this.textBox_protok_max.Location = new System.Drawing.Point(172, 100);
            this.textBox_protok_max.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_protok_max.Name = "textBox_protok_max";
            this.textBox_protok_max.Size = new System.Drawing.Size(76, 21);
            this.textBox_protok_max.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 165);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 15);
            this.label6.TabIndex = 18;
            this.label6.Text = "Najveća promjena";
            // 
            // textBox_protok_srednja
            // 
            this.textBox_protok_srednja.Location = new System.Drawing.Point(172, 67);
            this.textBox_protok_srednja.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_protok_srednja.Name = "textBox_protok_srednja";
            this.textBox_protok_srednja.Size = new System.Drawing.Size(76, 21);
            this.textBox_protok_srednja.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 134);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 15);
            this.label4.TabIndex = 16;
            this.label4.Text = "Mininalna vrijednost";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 70);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 15);
            this.label3.TabIndex = 15;
            this.label3.Text = "Srednja vrijednost";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 103);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 15);
            this.label2.TabIndex = 14;
            this.label2.Text = "Maksimalna vrijednost";
            // 
            // groupBox_graf
            // 
            this.groupBox_graf.Controls.Add(this.chart2);
            this.groupBox_graf.Location = new System.Drawing.Point(181, 10);
            this.groupBox_graf.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_graf.Name = "groupBox_graf";
            this.groupBox_graf.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_graf.Size = new System.Drawing.Size(529, 259);
            this.groupBox_graf.TabIndex = 4;
            this.groupBox_graf.TabStop = false;
            this.groupBox_graf.Text = "Pritisak";
            // 
            // chart2
            // 
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(17, 19);
            this.chart2.Margin = new System.Windows.Forms.Padding(2);
            this.chart2.Name = "chart2";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart2.Series.Add(series1);
            this.chart2.Size = new System.Drawing.Size(507, 224);
            this.chart2.TabIndex = 0;
            this.chart2.Text = "chart_pritisak";
            this.chart2.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.SystemDefault;
            // 
            // Nadzor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(743, 647);
            this.Controls.Add(this.label_status_ime);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button_odjava);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Nadzor";
            this.Text = "Nadzor";
            this.Load += new System.EventHandler(this.Nadzor_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox_pp.ResumeLayout(false);
            this.groupBox_pp.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox_dnevna.ResumeLayout(false);
            this.groupBox_dnevna.PerformLayout();
            this.groupBox_graf.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_status_ime;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button_odjava;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox_pp;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox_protok;
        private System.Windows.Forms.TextBox textBox_pritisak;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox_nivo;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox_ph;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox_trenutno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton_p2;
        private System.Windows.Forms.RadioButton radioButton_p1;
        private System.Windows.Forms.RadioButton radioButton_v2;
        private System.Windows.Forms.RadioButton radioButton_v1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox_graf;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBox_ph_prom;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_nivo_srednja;
        private System.Windows.Forms.TextBox textBox_nivo_max;
        private System.Windows.Forms.TextBox textBox_ph_min;
        private System.Windows.Forms.TextBox textBox_nivo_min;
        private System.Windows.Forms.TextBox textBox_ph_max;
        private System.Windows.Forms.TextBox textBox_nivo_prom;
        private System.Windows.Forms.TextBox textBox_ph_srednja;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox_dnevna;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_pritisak_prom;
        private System.Windows.Forms.TextBox textBox_pritisak_min;
        private System.Windows.Forms.TextBox textBox_pritisak_max;
        private System.Windows.Forms.TextBox textBox_pritisak_srednja;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_protok_prom;
        private System.Windows.Forms.TextBox textBox_protok_min;
        private System.Windows.Forms.TextBox textBox_protok_max;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_protok_srednja;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton radioButton_prit_ph;
        private System.Windows.Forms.RadioButton radioButton_prot_nivo;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton radioButton_hp2;
        private System.Windows.Forms.RadioButton radioButton_hp1;
        private System.Windows.Forms.RadioButton radioButton_hv2;
        private System.Windows.Forms.RadioButton radioButton_hv1;
    }
}