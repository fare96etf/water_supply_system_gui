﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DRAOS2_projekat_vodovod
{
    public partial class OglasnaTabla : Form
    {
        Klasa_Vodovod v;
        Klasa_Inzinjer eng;
        Klasa_Tehnolog tech;
        public OglasnaTabla()
        {
            InitializeComponent();
        }

        public OglasnaTabla(Klasa_Vodovod vod, Klasa_Inzinjer e)
        {
            InitializeComponent();
            v = vod;
            eng = e;
            label_status_ime.Text = e.Ime + ": " + e.Pozicija;
            foreach (string poruka in v.oglasna)
            {
                dataGridView1.Rows.Add(poruka);
            }
        }

        public OglasnaTabla(Klasa_Vodovod vod, Klasa_Tehnolog t)
        {
            InitializeComponent();
            v = vod;
            tech = t;
            label_status_ime.Text = t.Ime + ": " + t.Pozicija;
            foreach (string poruka in v.oglasna)
            {
                dataGridView1.Rows.Add(poruka);
            }
        }

        public OglasnaTabla(Klasa_Vodovod vod)
        {
            InitializeComponent();
            v = vod;
            label_status_ime.Text = "ADMINISTRATOR";
            foreach (string poruka in v.oglasna)
            {
                dataGridView1.Rows.Add(poruka);
            }
        }

        private void OglasnaTabla_Load(object sender, EventArgs e)
        {

        }

        private void button_nazad_Click(object sender, EventArgs e)
        {
            if (eng != null)
            {
                Inzinjer nova_forma = new Inzinjer(v, eng);
                this.Hide();
                nova_forma.ShowDialog();
                this.Close();
            }
            if (tech != null)
            {
                Tehnolog nova_forma = new Tehnolog(v, tech);
                this.Hide();
                nova_forma.ShowDialog();
                this.Close();
            }
            else
            {
                Admin admin = new Admin(v);
                this.Hide();
                admin.ShowDialog();
                this.Close();
            }
                
            
        }

        private void button_odjava_Click(object sender, EventArgs e)
        {
            Pocetna p = new Pocetna(v);
            this.Hide();
            p.ShowDialog();
            this.Close();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add(richTextBox1.Text);
            v.oglasna.Add(richTextBox1.Text);
        }
    }
}
