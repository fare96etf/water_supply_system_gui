﻿namespace DRAOS2_projekat_vodovod
{
    partial class Admin_dodaj
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_nazad = new System.Windows.Forms.Button();
            this.button_odjava = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_potvrda = new System.Windows.Forms.Button();
            this.textBox_mail = new System.Windows.Forms.TextBox();
            this.textBox_pass = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_un = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_tel = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_ime = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.radioButton_eng = new System.Windows.Forms.RadioButton();
            this.radioButton_tech = new System.Windows.Forms.RadioButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_dodaj = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_nazad
            // 
            this.button_nazad.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_nazad.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_nazad.Location = new System.Drawing.Point(188, 11);
            this.button_nazad.Margin = new System.Windows.Forms.Padding(2);
            this.button_nazad.Name = "button_nazad";
            this.button_nazad.Size = new System.Drawing.Size(67, 30);
            this.button_nazad.TabIndex = 17;
            this.button_nazad.Text = "NAZAD";
            this.button_nazad.UseVisualStyleBackColor = false;
            this.button_nazad.Click += new System.EventHandler(this.button_nazad_Click);
            // 
            // button_odjava
            // 
            this.button_odjava.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_odjava.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_odjava.Location = new System.Drawing.Point(271, 11);
            this.button_odjava.Margin = new System.Windows.Forms.Padding(2);
            this.button_odjava.Name = "button_odjava";
            this.button_odjava.Size = new System.Drawing.Size(67, 30);
            this.button_odjava.TabIndex = 16;
            this.button_odjava.Text = "ODJAVA";
            this.button_odjava.UseVisualStyleBackColor = false;
            this.button_odjava.Click += new System.EventHandler(this.button_odjava_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton_tech);
            this.groupBox1.Controls.Add(this.radioButton_eng);
            this.groupBox1.Controls.Add(this.button_potvrda);
            this.groupBox1.Controls.Add(this.textBox_mail);
            this.groupBox1.Controls.Add(this.textBox_pass);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox_un);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox_tel);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBox_ime);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(28, 46);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(310, 318);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Uredi korisnika";
            // 
            // button_potvrda
            // 
            this.button_potvrda.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_potvrda.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_potvrda.Location = new System.Drawing.Point(67, 283);
            this.button_potvrda.Margin = new System.Windows.Forms.Padding(2);
            this.button_potvrda.Name = "button_potvrda";
            this.button_potvrda.Size = new System.Drawing.Size(160, 30);
            this.button_potvrda.TabIndex = 15;
            this.button_potvrda.Text = "DODAJ KORISNIKA";
            this.button_potvrda.UseVisualStyleBackColor = false;
            this.button_potvrda.Click += new System.EventHandler(this.button_potvrda_Click);
            // 
            // textBox_mail
            // 
            this.textBox_mail.Location = new System.Drawing.Point(150, 132);
            this.textBox_mail.Name = "textBox_mail";
            this.textBox_mail.Size = new System.Drawing.Size(100, 20);
            this.textBox_mail.TabIndex = 8;
            // 
            // textBox_pass
            // 
            this.textBox_pass.Location = new System.Drawing.Point(150, 248);
            this.textBox_pass.Name = "textBox_pass";
            this.textBox_pass.Size = new System.Drawing.Size(100, 20);
            this.textBox_pass.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime i prezime";
            // 
            // textBox_un
            // 
            this.textBox_un.Location = new System.Drawing.Point(150, 208);
            this.textBox_un.Name = "textBox_un";
            this.textBox_un.Size = new System.Drawing.Size(100, 20);
            this.textBox_un.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Pozicija";
            // 
            // textBox_tel
            // 
            this.textBox_tel.Location = new System.Drawing.Point(150, 169);
            this.textBox_tel.Name = "textBox_tel";
            this.textBox_tel.Size = new System.Drawing.Size(100, 20);
            this.textBox_tel.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "E-Mail";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(47, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Broj telefona";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(47, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Korisničko ime";
            // 
            // textBox_ime
            // 
            this.textBox_ime.Location = new System.Drawing.Point(150, 48);
            this.textBox_ime.Name = "textBox_ime";
            this.textBox_ime.Size = new System.Drawing.Size(100, 20);
            this.textBox_ime.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(47, 248);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Šifra";
            // 
            // radioButton_eng
            // 
            this.radioButton_eng.AutoSize = true;
            this.radioButton_eng.Location = new System.Drawing.Point(134, 92);
            this.radioButton_eng.Name = "radioButton_eng";
            this.radioButton_eng.Size = new System.Drawing.Size(58, 17);
            this.radioButton_eng.TabIndex = 16;
            this.radioButton_eng.TabStop = true;
            this.radioButton_eng.Text = "Inžinjer";
            this.radioButton_eng.UseVisualStyleBackColor = true;
            // 
            // radioButton_tech
            // 
            this.radioButton_tech.AutoSize = true;
            this.radioButton_tech.Location = new System.Drawing.Point(198, 92);
            this.radioButton_tech.Name = "radioButton_tech";
            this.radioButton_tech.Size = new System.Drawing.Size(70, 17);
            this.radioButton_tech.TabIndex = 17;
            this.radioButton_tech.TabStop = true;
            this.radioButton_tech.Text = "Tehnolog";
            this.radioButton_tech.UseVisualStyleBackColor = true;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_dodaj});
            this.statusStrip1.Location = new System.Drawing.Point(0, 366);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(373, 22);
            this.statusStrip1.TabIndex = 18;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel_dodaj
            // 
            this.toolStripStatusLabel_dodaj.ForeColor = System.Drawing.Color.Red;
            this.toolStripStatusLabel_dodaj.Name = "toolStripStatusLabel_dodaj";
            this.toolStripStatusLabel_dodaj.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel_dodaj.Text = "toolStripStatusLabel1";
            // 
            // Admin_dodaj
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 388);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.button_nazad);
            this.Controls.Add(this.button_odjava);
            this.Controls.Add(this.groupBox1);
            this.Name = "Admin_dodaj";
            this.Text = "Admin_dodaj";
            this.Load += new System.EventHandler(this.Admin_dodaj_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_nazad;
        private System.Windows.Forms.Button button_odjava;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_potvrda;
        private System.Windows.Forms.TextBox textBox_mail;
        private System.Windows.Forms.TextBox textBox_pass;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_un;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_tel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_ime;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton radioButton_tech;
        private System.Windows.Forms.RadioButton radioButton_eng;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_dodaj;
    }
}