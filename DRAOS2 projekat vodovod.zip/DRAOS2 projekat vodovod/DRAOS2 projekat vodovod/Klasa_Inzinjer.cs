﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DRAOS2_projekat_vodovod
{
    public class Klasa_Inzinjer: Klasa_Osoba
    {
        public Klasa_Inzinjer(string i, string m, string tel, string un, string pass) : base(i, m, tel, un, pass)
        {
            pozicija = "Inžinjer";
        }
    }
}
